var gulp = require('gulp'),
less = require('gulp-less'),
cssmin = require('gulp-minify-css'),
concat = require('gulp-concat');

gulp.task('fn1', function () { //fn1就是运行gulp的“方法”
    gulp.src(['less/index.less','less/index2.less']) //需要处理的文件
        .pipe(less()) //调用引入的插件模块
        .pipe(gulp.dest('css')); //将会在css下生成index.css   输出的路径
});

gulp.task('mincss',function(){
	gulp.src('css/index.css')
	.pipe(cssmin())
	.pipe(gulp.dest('css/min'))
})

gulp.task('contjs', function () { //fn1就是运行gulp的“方法”
    gulp.src('js/*.js') //需要处理的文件
        .pipe(concat('all.js')) //调用引入的插件模块
        .pipe(gulp.dest('js/min')); //将会在css下生成index.css   输出的路径
});


gulp.task('t', function () {
    gulp.watch(['less/*.less','css/index.css'], ['fn1','mincss']);
});
